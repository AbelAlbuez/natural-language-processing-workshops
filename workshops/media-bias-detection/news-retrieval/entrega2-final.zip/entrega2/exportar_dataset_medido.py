"""Exporta el conjunto de datos medido del corte Duque (Entrega 2, punto 3).

Une el Parquet de entrada con las métricas por documento ya calculadas y agrega
las columnas que pide el enunciado y que faltaban: titular limpio y tokens.
Usa `core.normalize` y `core.tokenize` con las mismas stopwords del análisis,
así que los tokens coinciden exactamente con los que alimentaron las métricas.

Uso (desde la carpeta entrega2/):
    python exportar_dataset_medido.py --input /ruta/duque-candidatos.parquet

Salida en resultados/dataset_medido/:
    corpus_<medio>.parquet   un archivo por medio (todos < 100 MB)
    muestra.csv              300 filas por medio, legible en Excel
    DICCIONARIO_DATOS.md     descripción de cada columna
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from core import normalize, tokenize

COLUMNAS = {
    "article_id": "Identificador del artículo",
    "source_id": "Medio",
    "published_date": "Fecha almacenada (día o mes, ver date_precision)",
    "year": "Año",
    "date_precision": "Precisión de la fecha: day o month",
    "url": "URL original",
    "title": "Titular reconstruido desde la URL",
    "title_source": "Procedencia del titular (slug)",
    "titulo_limpio": "Titular normalizado: minúsculas, sin tildes, solo letras",
    "tokens": "Tokens de contenido (sin stopwords ni verbos de reporte, > 2 letras)",
    "num_tokens": "Número de tokens de contenido",
    "ttr": "TTR del titular",
    "msttr_titulo": "MSTTR del titular",
    "yule_k": "K de Yule del titular",
    "dominant_topic": "Tópico LDA dominante (K=5); -1 = sin vocabulario LDA",
    "topic_confidence": "Probabilidad del tópico dominante",
}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--input", required=True, type=Path, help="Parquet de entrada del corte Duque")
    ap.add_argument("--resultados", default=Path("resultados"), type=Path)
    ap.add_argument("--muestra", default=300, type=int, help="Filas por medio en muestra.csv")
    args = ap.parse_args()

    stop = set(json.loads((args.resultados / "stopwords.json").read_text(encoding="utf-8")))
    base = pd.read_parquet(args.input)
    faltan = {"article_id", "source_id", "title"} - set(base.columns)
    if faltan:
        raise SystemExit(f"El Parquet de entrada no tiene las columnas: {sorted(faltan)}")

    base = base[[c for c in ("article_id", "source_id", "url", "title") if c in base.columns]]
    base["titulo_limpio"] = base["title"].map(normalize)
    base["tokens"] = base["title"].map(lambda t: tokenize(t, stop))

    topicos = pd.read_parquet(args.resultados / "document_topics.parquet")
    diversidad = pd.read_parquet(args.resultados / "diversidad_documentos.parquet").drop(
        columns="source_id"
    )
    datos = topicos.merge(base.drop(columns="source_id"), on="article_id", how="left").merge(
        diversidad, on="article_id", how="left"
    )
    if len(datos) != len(topicos):
        raise SystemExit("La unión cambió el número de filas: revisar article_id duplicados")

    # Comprobación: los tokens regenerados deben dar el mismo conteo ya publicado.
    con_titulo = datos["tokens"].notna()
    distintos = (datos.loc[con_titulo, "tokens"].map(len) != datos.loc[con_titulo, "num_tokens"]).sum()
    print(f"Filas: {len(datos):,} · con titular: {con_titulo.sum():,} · "
          f"conteos de tokens que no coinciden: {distintos:,}")

    datos = datos[[c for c in COLUMNAS if c in datos.columns]]
    salida = args.resultados / "dataset_medido"
    salida.mkdir(parents=True, exist_ok=True)
    for medio, sub in datos.groupby("source_id"):
        ruta = salida / f"corpus_{medio}.parquet"
        sub.to_parquet(ruta, index=False, compression="zstd")
        print(f"  {ruta.name}: {len(sub):,} filas · {ruta.stat().st_size / 1e6:.1f} MB")

    muestra = datos.sample(frac=1, random_state=42).groupby("source_id").head(args.muestra).copy()
    muestra["tokens"] = muestra["tokens"].map(lambda t: " | ".join(t) if isinstance(t, list) else "")
    muestra.to_csv(salida / "muestra.csv", index=False, encoding="utf-8-sig")

    dic = pd.DataFrame({"columna": list(COLUMNAS), "descripción": list(COLUMNAS.values())})
    dic = dic[dic["columna"].isin(datos.columns)]
    (salida / "DICCIONARIO_DATOS.md").write_text(
        "# Diccionario de datos — conjunto medido (corte Duque)\n\n"
        + dic.to_markdown(index=False) + "\n", encoding="utf-8"
    )
    print(f"Listo → {salida}")


if __name__ == "__main__":
    main()
